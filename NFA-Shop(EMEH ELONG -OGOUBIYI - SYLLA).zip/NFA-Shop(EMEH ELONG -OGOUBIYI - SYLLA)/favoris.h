//
// Created by Aboubacar Sylla on 02/11/2026.
//


#ifndef SHOPFLOW_FAVORIS_H
#define SHOPFLOW_FAVORIS_H

#include "types.h"

/* Verifier si une reference est deja dans les favoris.
   Retour : 1 si presente, 0 sinon. */
int estFavori(const Client *client, const char *reference);

/* Ajouter un produit existant et actif aux favoris.
   Retour : 1 si ajoute, 0 si refuse. */
int ajouterFavori(const Boutique *boutique,Client *client,const char *reference);

/* Retirer un produit des favoris.
   Retour : 1 si retire, 0 si absent ou arguments invalides. */
int retirerFavori(Client *client, const char *reference);

/* Afficher les produits favoris du client. */
void afficherFavoris(const Boutique *boutique,const Client *client);

#endif //SHOPFLOW_FAVORIS_H
