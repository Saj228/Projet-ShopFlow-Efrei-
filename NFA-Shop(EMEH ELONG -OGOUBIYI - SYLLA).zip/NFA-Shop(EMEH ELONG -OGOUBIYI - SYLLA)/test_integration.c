#include "initialisation.h"
#include "commande.h"
#include "produit.h"
#include "statistique.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void proche(float obtenu, double attendu)
{
    assert(fabs((double)obtenu - attendu) < 0.02);
}

int main(void)
{
    Boutique b = {0};
    assert(initialiserDonneesTest(&b));
    assert(b.nbProduits == 8 && b.nbClients == 5);
    assert(b.numeroSuivant == 1007 && b.idClientSuivant == 6);
    assert(!initialiserDonneesTest(&b));
    int commandes = 0, longues = 0, grosses = 0;
    int statuts[4] = {0}, vus[6] = {0};
    const char *nom[] = {"EN_COURS", "EXPEDIEE", "LIVREE", "ANNULEE"};
    int initiaux[] = {42, 8, 6, 25, 12, 120, 4, 18};
    double htTotal = 0, ttcTotal = 0, htOctobre = 0;
    for (int i = 0; i < b.nbClients; i++) {
        const Client *client = &b.clients[i];
        assert(client->idClient == i + 1);
        assert(strlen(client->telephone) == 10);
        assert(strlen(client->adresse.codePostal) == 5);
        assert(client->adresse.Rue[0] && client->adresse.Ville[0]);
        int points = 0;
        for (int j = 0; j < client->nbCommandes; j++) {
            const Commande *c = &client->commandes[j];
            commandes++;
            assert(c->numero >= 1001 && c->numero < 1007);
            assert(!vus[c->numero - 1001]++);
            assert(c->idClient == client->idClient);
            assert(c->lignes && c->nbLignes > 0);
            assert(c->capaciteLignes >= c->nbLignes);
            assert(strcmp(c->adresseLivraison.Rue, client->adresse.Rue) == 0);
            for (int k = 0; k < 4; k++) {
                if (strcmp(c->statut, nom[k]) == 0) statuts[k]++;
            }
            double brut = 0;
            for (int k = 0; k < c->nbLignes; k++) {
                const LigneCommande *l = &c->lignes[k];
                assert(l->quantite > 0);
                assert(rechercherProduit(&b, l->refProduit));
                brut += l->quantite * (double)l->prixUnitaireHT;
            }
            proche(c->montantBrutHT, brut);
            double remise = brut < 100 ? 0 : brut < 300 ? 5 : brut < 600 ? 10 : 15;
            double ht = brut * (1 - remise / 100);
            double port = brut >= 60 ? 0 : 5.90;
            proche(c->montantHT, ht);
            proche(c->montantTTC, ht * 1.2 + port);
            if (c->nbLignes >= 3) longues++;
            if (brut > 600) grosses++;
            if (strcmp(c->statut, "ANNULEE") != 0) {
                htTotal += ht;
                ttcTotal += ht * 1.2 + port;
                if (c->dateCommande.mois == 10) htOctobre += ht;
                points += (int)(c->montantTTC / 10.0f);
            }
        }
        assert(client->pointsFidelite == points);
    }
    assert(commandes == 6 && longues >= 2 && grosses >= 1);
    for (int i = 0; i < 4; i++) assert(statuts[i] > 0);
    int alertes = 0;
    for (int i = 0; i < b.nbProduits; i++) {
        int vendu = calculerQuantiteVendue(&b, b.produits[i].reference);
        assert(b.produits[i].quantiteStock == initiaux[i] - vendu);
        if (b.produits[i].quantiteStock <= b.produits[i].seuilAlerte) alertes++;
    }
    assert(alertes >= 2);
    proche(calculerChiffreAffairesHT(&b), htTotal);
    proche(calculerChiffreAffairesTTC(&b), ttcTotal);
    proche(calculerChiffreAffairesHTParMois(&b, 10, 2026), htOctobre);
    proche(calculerChiffreAffairesHTParAnnee(&b, 2026), htTotal);
    proche(calculerChiffreAffairesTTCParAnnee(&b, 2026), ttcTotal);
    assert(calculerChiffreAffairesHTParMois(&b, 13, 2026) == 0);
    afficherClassementClients(&b);
    afficherTop5Produits(&b);
    detruireBoutique(&b);
    detruireBoutique(&b);
    assert(b.produits == NULL && b.clients == NULL);

    Commande c = {0};
    assert(!ajouterLigne(NULL, "A", "Test", 1, 1));
    assert(!ajouterLigne(&c, "REFERENCE-TROP-LONGUE", "Test", 1, 1));
    assert(!ajouterLigne(&c, "A", "Test", 0, 1));
    assert(ajouterLigne(&c, "A", "Test", 1, 600));
    proche(c.tauxRemise, 15);
    assert(!ajouterLigne(&c, "A", "Test", 1, 600));
    c.lignes[0].prixUnitaireHT = 10;
    c.lignes[0].sousTotalHT = 10;
    calculCommande(&c);
    proche(c.montantRemise, 0);
    proche(c.montantTTC, 17.90);
    free(c.lignes);
    puts("Tests d'integration : OK (donnees, montants, stocks, points, allocations).");
    return 0;
}
