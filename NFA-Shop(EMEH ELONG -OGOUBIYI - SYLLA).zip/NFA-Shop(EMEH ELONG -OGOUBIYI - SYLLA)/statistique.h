//
// Created by Aboubacar Sylla on 28/10/2026.
//
//
#ifndef SHOPFLOW_STATISTIQUE_H
#define SHOPFLOW_STATISTIQUE_H

#include "types.h"

/* Calcule le chiffre d'affaires HT hors commandes annulees. */
float calculerChiffreAffairesHT(const Boutique *b);
/* Calcule le chiffre d'affaires TTC hors commandes annulees. */
float calculerChiffreAffairesTTC(const Boutique *b);
/* Calcule le chiffre d'affaires HT PAR MOIS hors commandes annulees. */
float calculerChiffreAffairesHTParMois(const Boutique *b, int mois , int annee);
/* Calcule le chiffre d'affaires TTC PAR MOIS  hors commandes annulees. */
float calculerChiffreAffairesTTCParMois(const Boutique *b, int mois , int annee);
/* Calcule le chiffre d'affaires HT PAR ANNEE hors commandes annulees. */
float calculerChiffreAffairesHTParAnnee(const Boutique *b, int annee);
/* Calcule le chiffre d'affaires TTC PAR ANNEE hors commandes annulees. */
float calculerChiffreAffairesTTCParAnnee(const Boutique *b, int annee);
/* Calcule le chiffre d'affaires DU CLIENT TTC hors commandes annulees. */
float calculerChiffreAffairesClientTTC(const Client *client);
/* AFFICHER LE CLASSEMENTS DES CLIENTS hors commandes annulees. */
void afficherClassementClients(const Boutique *b);
/* Calcule la Quantite Vendue  hors commandes annulees. */
int calculerQuantiteVendue(const Boutique *b, const char *reference);
/* Affiche le Top 5 des Produits les plus vendus hors commandes annulees. */
void afficherTop5Produits(const Boutique *b);

#endif
