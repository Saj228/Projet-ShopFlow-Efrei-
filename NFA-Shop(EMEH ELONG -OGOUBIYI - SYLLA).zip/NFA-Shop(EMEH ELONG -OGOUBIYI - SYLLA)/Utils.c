
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include "utils.h"

// Saisie sécurisée d'un texte
int lireTexte(const char message[], char destination[], int taille)
{
    printf("%s", message);

    if (fgets(destination, taille, stdin) == NULL)
    {
        return 0;
    }

    // Vérifier si toute la saisie tient dans le tableau
    if (strchr(destination, '\n') == NULL)
    {
        int c;

        while ((c = getchar()) != '\n' && c != EOF);

        printf("Saisie trop longue !\n");
        return 0;
    }

    // Supprimer le retour à la ligne
    destination[strcspn(destination, "\n")] = '\0';

    return 1;
}

// Saisie sécurisée d'un entier
int lireEntier(const char message[], int *valeur)
{
    char saisie[50];
    char *fin;
    long resultat;

    printf("%s", message);

    if (fgets(saisie, sizeof(saisie), stdin) == NULL)
    {
        return 0;
    }

    if (strchr(saisie, '\n') == NULL)
    {
        int c;
        while ((c = getchar()) != '\n' && c != EOF);
        return 0;
    }

    errno = 0;
    resultat = strtol(saisie, &fin, 10);

    while (isspace((unsigned char)*fin))
    {
        fin++;
    }

    if (fin == saisie || *fin != '\0' || errno != 0)
    {
        printf("Veuillez saisir un entier valide.\n");
        return 0;
    }

    *valeur = (int)resultat;
    return 1;
}

// Saisie sécurisée d'un réel
int lireReel(const char message[], float *valeur)
{
    char saisie[50];
    char *fin;
    float resultat;

    printf("%s", message);

    if (fgets(saisie, sizeof(saisie), stdin) == NULL)
    {
        return 0;
    }

    if (strchr(saisie, '\n') == NULL)
    {
        int c;
        while ((c = getchar()) != '\n' && c != EOF);
        return 0;
    }

    errno = 0;
    resultat = strtof(saisie, &fin);

    while (isspace((unsigned char)*fin))
    {
        fin++;
    }

    if (fin == saisie || *fin != '\0' || errno != 0)
    {
        printf("Veuillez saisir un nombre valide.\n");
        return 0;
    }

    *valeur = resultat;
    return 1;
}

// Vérifier qu'un texte n'est pas vide
int texteNonVide(const char texte[])
{
    int i = 0;

    while (isspace((unsigned char)texte[i]))
    {
        i++;
    }

    return texte[i] != '\0';
}

// Vérifier la présence du caractère @
int verifierEmail(const char email[])
{
    const char *arobase = strchr(email, '@');

    return arobase != NULL
           && arobase != email
           && arobase[1] != '\0';
}

// Vérifier un numéro de téléphone de 10 chiffres
int verifierTelephone(const char telephone[])
{
    int i;

    if (strlen(telephone) != 10)
    {
        return 0;
    }

    for (i = 0; telephone[i] != '\0'; i++)
    {
        if (!isdigit((unsigned char)telephone[i]))
        {
            return 0;
        }
    }

    return 1;
}

// Vérifier un code postal de 5 chiffres
int verifierCodePostal(const char codePostal[])
{
    int i;

    if (strlen(codePostal) != 5)
    {
        return 0;
    }

    for (i = 0; codePostal[i] != '\0'; i++)
    {
        if (!isdigit((unsigned char)codePostal[i]))
        {
            return 0;
        }
    }

    return 1;
}

// Afficher un titre
void afficherTitre(const char titre[])
{
    printf("\n");
    afficherSeparateur(60);
    printf("%s\n", titre);
    afficherSeparateur(60);
}

// Afficher une ligne de séparation
void afficherSeparateur(int longueur)
{
    int i;

    for (i = 0; i < longueur; i++)
    {
        printf("=");
    }

    printf("\n");
}
