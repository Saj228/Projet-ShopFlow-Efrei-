//
// Created by Aboubacar Sylla on 02/11/2026.
//
#include "favoris.h"

#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "types.h"

/* Comparer les references pour savoir si le produit figure deja dans la liste. */
int estFavori(const Client *client, const char *reference)
{
    if (client == NULL || reference == NULL) {
        return 0;
    }
    for (int i = 0; i< client->nbFavoris; i++) {
        if (strcmp(client->favoris[i], reference) == 0) {
            return 1;
        }
    }
    return 0;
}

int ajouterFavori(const Boutique *boutique,
                  Client *client,
                  const char *reference)
{
    if (boutique == NULL || client == NULL || reference == NULL) {
        return 0;
    }

    if (!client->actif || reference[0] == '\0'
        || strlen(reference) >= TAILLE_REF) {
        return 0;
        }

    /* Refuser les doublons. */
    if (estFavori(client, reference)) {
        return 0;
    }

    /* Verifier que le produit existe et qu'il est actif. */
    int produitTrouve = 0;

    for (int i = 0; i < boutique->nbProduits; i++) {
        const Produit *produit = &boutique->produits[i];

        if (strcmp(produit->reference, reference) == 0
            && produit->actif) {
            produitTrouve = 1;
            break;
            }
    }

    if (!produitTrouve) {
        return 0;
    }

    /* Agrandir le tableau lorsqu'il est plein. */
    if (client->nbFavoris == client->capaciteFavoris) {
        if (client->capaciteFavoris > INT_MAX / 2) {
            return 0;
        }

        int nouvelleCapacite;

        if (client->capaciteFavoris == 0) {
            nouvelleCapacite = 4;
        } else {
            nouvelleCapacite = client->capaciteFavoris * 2;
        }

        if ((size_t)nouvelleCapacite
            > SIZE_MAX / sizeof(*client->favoris)) {
            return 0;
            }

        char (*nouveauxFavoris)[TAILLE_REF] =
            realloc(client->favoris,
                    (size_t)nouvelleCapacite
                    * sizeof(*client->favoris));

        if (nouveauxFavoris == NULL) {
            return 0;
        }

        client->favoris = nouveauxFavoris;
        client->capaciteFavoris = nouvelleCapacite;
    }

    /* Enregistrer la reference dans le prochain emplacement. */
    strcpy(client->favoris[client->nbFavoris], reference);
    client->nbFavoris++;

    return 1;
}

/* Apres retrait, decaler les references pour garder les favoris consecutifs.
 * La capacite reste disponible pour de futurs ajouts. */
int retirerFavori(Client *client, const char *reference)
{
    if (client == NULL || reference == NULL) {
        return 0;
    }

    for (int i = 0; i < client->nbFavoris; i++) {
        if (strcmp(client->favoris[i], reference) == 0) {

            /* Decaler les favoris suivants d'une place. */
            for (int j = i; j < client->nbFavoris - 1; j++) {
                strcpy(client->favoris[j],
                       client->favoris[j + 1]);
            }

            client->nbFavoris--;

            /* Vider l'ancien dernier emplacement. */
            client->favoris[client->nbFavoris][0] = '\0';

            return 1;
        }
    }

    return 0;
}
/* Rechercher les references dans le catalogue afin d'afficher prix et stock actuels.
 * Les references restent valides meme si realloc deplace le tableau des produits. */
void afficherFavoris(const Boutique *boutique,
                     const Client *client)
{
    if (boutique == NULL || client == NULL) {
        printf("Impossible d'afficher les favoris.\n");
        return;
    }

    printf("\n=== Favoris de %s %s ===\n",
           client->prenom, client->nom);

    if (client->nbFavoris == 0) {
        printf("Aucun produit dans les favoris.\n");
        return;
    }

    for (int i = 0; i < client->nbFavoris; i++) {
        const Produit *produitTrouve = NULL;

        /* Retrouver le produit grace a sa reference. */
        for (int j = 0; j < boutique->nbProduits; j++) {
            if (strcmp(client->favoris[i],
                       boutique->produits[j].reference) == 0) {
                produitTrouve = &boutique->produits[j];
                break;
                       }
        }

        if (produitTrouve == NULL) {
            printf("%d. %s : produit introuvable.\n",
                   i + 1, client->favoris[i]);
        } else if (!produitTrouve->actif) {
            printf("%d. %s - %s : produit desactive.\n",
                   i + 1,
                   produitTrouve->reference,
                   produitTrouve->designation);
        } else {
            printf("%d. %s - %s | %.2f EUR HT | Stock : %d\n",
                   i + 1,
                   produitTrouve->reference,
                   produitTrouve->designation,
                   produitTrouve->prixUnitaireHT,
                   produitTrouve->quantiteStock);
        }
    }
}