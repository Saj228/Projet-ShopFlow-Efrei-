//
// Created by Aboubacar Sylla on 28/10/2026.
//
#include "statistique.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

float calculerChiffreAffairesHT(const Boutique *b)
{
    float total = 0.0f;

    if (b == NULL) {
        return 0.0f;
    }
    /*Parcourir les clients. */
    for (int i = 0; i < b->nbClients; i++) {

        /*Parcourir les commandes de chaque clients*/
        for (int j = 0; j < b->clients[i].nbCommandes; j++) {
            const Commande *commande = &b->clients[i].commandes[j];

            /*Ajouter le montant seulement si la commande n'est pas annulée*/
            if (strcmp(commande->statut, "ANNULEE") != 0) {

                total += commande->montantHT;
            }

        }
    }

    return total;

}
float calculerChiffreAffairesTTC(const Boutique *b) {
    float total = 0.0f;
    if (b == NULL) {
        return 0.0f;
    }
    for (int i = 0; i < b->nbClients; i++) {
        for (int j = 0; j < b->clients[i].nbCommandes; j++) {
            const Commande *commande = &b->clients[i].commandes[j];
            if (strcmp(commande->statut, "ANNULEE") != 0) {
                total += commande->montantTTC;
            }
        }
    }
    return total;
}
/* Selectionner les commandes non annulees du mois ET de l'annee demandes. */
float calculerChiffreAffairesHTParMois(const Boutique *b, int mois , int annee) {
    float total = 0.0f;
    if (b == NULL || mois <1 || mois > 12 || annee < 2000 || annee > 2100){
        return 0.0f;
    }
    for (int i = 0; i < b->nbClients; i++) {
        for (int j = 0; j < b->clients[i].nbCommandes; j++) {
            const Commande *commande = &b->clients[i].commandes[j];
            if (strcmp(commande->statut, "ANNULEE") != 0
    && commande->dateCommande.mois == mois
    && commande->dateCommande.annee == annee) {

                total += commande->montantHT;
    }

        }
    }
    return total;
}
float calculerChiffreAffairesTTCParMois(const Boutique *b, int mois , int annee) {
        float total = 0.0f;
        if (b == NULL || mois < 1 || mois > 12 || annee < 2000 || annee > 2100) {
            return 0.0f;
        }
        for (int i = 0; i < b->nbClients; i++) {
            for (int j = 0; j < b->clients[i].nbCommandes; j++) {
                const Commande *commande = &b->clients[i].commandes[j];
                if (strcmp(commande->statut, "ANNULEE") != 0
                    && commande->dateCommande.mois == mois
                    && commande->dateCommande.annee == annee) {
                    total += commande->montantTTC;
                }
            }
        }
        return total;
    }
/* Reutiliser le calcul mensuel pour additionner les douze mois de l'annee. */
float calculerChiffreAffairesHTParAnnee(const Boutique *b, int annee) {
    float total = 0.0f;
    if (b == NULL || annee <2000 || annee > 2100) {
        return 0.0f;
    }
    for (int mois =1; mois <=12; mois++) {
        total += calculerChiffreAffairesHTParMois(b,mois,annee);
    }
    return total;
}
float calculerChiffreAffairesTTCParAnnee(const Boutique *b, int annee) {
    float total = 0.0f;
    if (b == NULL || annee <2000 || annee > 2100) {
        return 0.0f;
    }
    for (int mois = 1; mois <=12; mois++) {
        total += calculerChiffreAffairesTTCParMois(b,mois, annee);
    }
    return total;
}
float calculerChiffreAffairesClientTTC(const Client *client) {
    float total = 0.0f;
    if (client == NULL) {
        return 0.0f;
    }
    for (int j = 0; j < client->nbCommandes; j++) {
        const Commande *commande = &client->commandes[j];
        if (strcmp(commande->statut, "ANNULEE") != 0) {
            total += commande->montantTTC;
        }
    }
    return total;
}
/* Trier un tableau temporaire : l'ordre des clients de la boutique est conserve. */
void afficherClassementClients(const Boutique *b) {
    if (b ==NULL || b->nbClients <= 0) {
        printf("Aucun client a classer.\n");
        return;
    }
    /*une case contient un client et son chiffre d'affaires.*/
    ResultatClient *classement = malloc ((size_t)b->nbClients * sizeof(*classement));
    if (classement ==NULL) {
        printf("Erreur : allocation du classement impossible.\n");
        return;
    }
    /*remplir le tableau temporaire.*/
    for (int i = 0; i < b->nbClients; i++) {
        classement[i].client = &b->clients[i];

        classement[i].chiffreAffaires = calculerChiffreAffairesClientTTC(&b->clients[i]);

    }
    /* tri par selection : placer le plus grand montant en premier .*/
    for (int i = 0; i < b->nbClients; i++) {
        int indiceMax = i;
        for (int j = i + 1; j < b->nbClients; j++) {
            if (classement[j].chiffreAffaires > classement[indiceMax].chiffreAffaires) {
                indiceMax = j;
            }
        }
        ResultatClient temporaire = classement[i];
        classement[i] = classement[indiceMax];
        classement[indiceMax] = temporaire;
    }
    printf("\n=== Classement des clients par Chiffres Affaires TTC ===\n");

    for (int i = 0; i < b->nbClients; i++) {
        const Client *client = classement[i].client;
        printf("%d. Client %d - %s %s : %.2f euros \n",
        i+1,
        client->idClient,
        client->prenom,
        client->nom,
        classement[i].chiffreAffaires);
    }
    /* Liberer uniquement le tableau temporaire.*/
    free(classement);
}

/* Additionner les quantites des lignes portant la reference, hors annulations. */
int calculerQuantiteVendue(const Boutique *b, const char *reference) {
    int total =0;
    if (b== NULL || reference == NULL) {
        return 0;
    }
    for (int i = 0; i < b->nbClients;i++) {
        for (int j = 0; j < b->clients[i].nbCommandes; j++) {
            const Commande *commande = &b->clients[i].commandes[j];

            /*Ignorer les commandes annulees.*/
            if (strcmp(commande->statut, "ANNULEE") == 0) {
                continue;
            }
            for (int k= 0; k < commande->nbLignes; k++) {
                const LigneCommande *ligne = &commande->lignes[k];
                if (strcmp(ligne->refProduit, reference) == 0) {
                    total += ligne->quantite;
                }
            }
        }
    }
    return total;
}

void afficherTop5Produits(const Boutique *b) {
    if (b == NULL || b->nbProduits <= 0) {
        printf("Aucun produit a classer.\n");
        return;
    }
    ResultatProduit *classement = malloc ((size_t)b->nbProduits * sizeof(*classement));
    if (classement ==NULL) {
        printf("Erreur : allocation du classement impossible.\n");
        return;
    }
    /*Calculer les ventes de chaque produit.*/
    for (int i = 0; i < b->nbProduits; i++) {
        classement[i].produit = &b->produits[i];

        classement[i].quantiteVendue = calculerQuantiteVendue(b, b->produits[i].reference);
    }

    /*Trier les quantites de la plus grande à a plus petite .*/

    for (int i = 0; i < b->nbProduits - 1; i++) {
        int indiceMax = i;

        for (int j = i + 1; j < b->nbProduits; j++) {
            if (classement[j].quantiteVendue > classement[indiceMax].quantiteVendue) {
                indiceMax = j;
            }
        }
        ResultatProduit temporaire = classement[i];
        classement[i] = classement[indiceMax];
        classement[indiceMax] = temporaire;
    }
    int limite = b->nbProduits;
    if (limite > 5) {
        limite = 5;
    }
    printf("\n=== Top 5 des produits par quantite vendue ===\n");
    int nbAffiches = 0;
    for (int i = 0;i < limite; i++) {
        if (classement[i].quantiteVendue == 0) {
        break;
        }
        const Produit *produit = classement[i].produit;
        printf("%d. %s - %s : %d unite(s) \n",
            i+ 1,
            produit->reference,
            produit->designation,
            classement[i].quantiteVendue);
        nbAffiches++;
    }
    if (nbAffiches == 0) {
        printf("Aucune vente pour le moment. \n");
    }
    free(classement);
}