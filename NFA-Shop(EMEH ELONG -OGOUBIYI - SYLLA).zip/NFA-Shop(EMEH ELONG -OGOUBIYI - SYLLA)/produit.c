#include "produit.h"
#include <ctype.h>
#include <limits.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Une chaine doit se terminer dans le tableau et contenir autre chose
 * que des espaces. Cette fonction reste privee au module (static). */
static int texteValide(const char *texte, size_t taille)
{
    int contientCaractere = 0;

    for (size_t i = 0; i < taille; i++) {
        if (texte[i] == '\0') {
            return contientCaractere;
        }
        if (!isspace((unsigned char)texte[i])) {
            contientCaractere = 1;
        }
    }
    return 0;
}

static int catalogueValide(const Boutique *b)
{
    return b != NULL
        && b->nbProduits >= 0
        && b->capaciteProduits >= b->nbProduits
        && (b->capaciteProduits == 0 || b->produits != NULL);
}

Produit *rechercherProduit(Boutique *b, const char *reference)
{
    if (!catalogueValide(b) || reference == NULL) {
        return NULL;
    }

    for (int i = 0; i < b->nbProduits; i++) {
        if (strcmp(b->produits[i].reference, reference) == 0) {
            return &b->produits[i];
        }
    }
    return NULL;
}

int ajouterProduit(Boutique *b, Produit nouveauProduit)
{
    if (!catalogueValide(b)) {
        return 0;
    }

    /* Les tailles incluent le caractere final '\0'. */
    if (!texteValide(nouveauProduit.reference,
                     sizeof nouveauProduit.reference)
        || !texteValide(nouveauProduit.designation,
                        sizeof nouveauProduit.designation)
        || !texteValide(nouveauProduit.categorie,
                        sizeof nouveauProduit.categorie)
        || !isfinite(nouveauProduit.prixUnitaireHT)
        || nouveauProduit.prixUnitaireHT <= 0.0f
        || nouveauProduit.quantiteStock < 0
        || nouveauProduit.seuilAlerte < 0) {
        return 0;
    }

    /* La reference reste reservee meme si le produit est desactive. */
    if (rechercherProduit(b, nouveauProduit.reference) != NULL) {
        return 0;
    }

    if (b->nbProduits == b->capaciteProduits) {
        int nouvelleCapacite;

        if (b->capaciteProduits == 0) {
            nouvelleCapacite = 4;
        } else {
            /* Eviter un debordement lors du doublement. */
            if (b->capaciteProduits > INT_MAX / 2) {
                return 0;
            }
            nouvelleCapacite = b->capaciteProduits * 2;
        }

        if ((size_t)nouvelleCapacite > SIZE_MAX / sizeof(Produit)) {
            return 0;
        }

        /* realloc(NULL, taille) effectue la premiere allocation.
         * Le pointeur temporaire conserve l'ancien tableau en cas d'echec. */
        Produit *temp = realloc(b->produits,
                               (size_t)nouvelleCapacite * sizeof(Produit));
        if (temp == NULL) {
            return 0;
        }

        b->produits = temp;
        b->capaciteProduits = nouvelleCapacite;
    }

    nouveauProduit.actif = 1;
    b->produits[b->nbProduits] = nouveauProduit;
    b->nbProduits++;
    return 1;
}

void afficherProduits(const Boutique *b)
{
    if (!catalogueValide(b)) {
        printf("Erreur : catalogue non initialise correctement.\n");
        return;
    }
    if (b->nbProduits == 0) {
        printf("Le catalogue est vide.\n");
        return;
    }

    double valeurTotale = 0.0;
    printf("\n=== Catalogue : %d produit(s) ===\n", b->nbProduits);

    for (int i = 0; i < b->nbProduits; i++) {
        const Produit *p = &b->produits[i];
        double valeurStock = (double)p->prixUnitaireHT * p->quantiteStock;
        valeurTotale += valeurStock;

        printf("\n%s - %s\n", p->reference, p->designation);
        printf("Categorie : %s | Etat : %s\n", p->categorie,
               p->actif ? "actif" : "desactive");
        printf("Prix HT : %.2f EUR | Stock : %d | Seuil : %d\n",
               p->prixUnitaireHT, p->quantiteStock, p->seuilAlerte);
        printf("Valeur du stock HT : %.2f EUR\n", valeurStock);
    }

    printf("\nValeur totale du stock HT : %.2f EUR\n", valeurTotale);
}
