#ifndef CLIENT_H
#define CLIENT_H

#include "types.h"

void ajouterClient(void);

void modifierClient(void);

void supprimerClient(void);

void afficherListeClients(void);

#endif
