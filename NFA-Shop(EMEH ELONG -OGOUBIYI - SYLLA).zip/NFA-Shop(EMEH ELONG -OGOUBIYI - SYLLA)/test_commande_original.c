//
// Created by nemeh on 28/10/2026.
//
#include <stdio.h>
#include <stdlib.h>
#include "types.h"
#include "commande.h"

int main(void)
{
    Commande c = {0};             /* {0} met tous les champs à zéro */

    ajouterLigne(&c, "PRD-0001", "Clavier", 2, 79.90f);
    ajouterLigne(&c, "PRD-0002", "Souris", 1, 24.50f);
    ajouterLigne(&c, "PRD-0003", "Ecran", 1, 199.00f);

    calculCommande(&c);           /* &c = l'adresse de c, comme paul plus tôt */

    printf("Brut   : %.2f\n", c.montantBrutHT);
    printf("Taux   : %.0f %%\n", c.tauxRemise);
    printf("Remise : %.2f\n", c.montantRemise);
    printf("HT     : %.2f\n", c.montantHT);
    printf("TVA    : %.2f\n", c.montantTVA);
    printf("Port   : %.2f\n", c.fraisPort);
    printf("TTC    : %.2f\n", c.montantTTC);

    free(c.lignes);

    return 0;
}