#ifndef PRODUIT_H
#define PRODUIT_H

#include "types.h"

/* Renvoie 1 si l'ajout reussit, 0 si les donnees, la reference ou
 * l'allocation ne conviennent pas. En cas d'echec, le catalogue ne change pas.
 * La boutique doit etre initialisee, par exemple avec Boutique b = {0};
 * Un nouveau produit est automatiquement actif. */
int ajouterProduit(Boutique *b, Produit nouveauProduit);

/* Recherche exacte, y compris parmi les produits desactives.
 * Renvoie NULL si la reference est absente ou si les arguments sont invalides.
 * Attention : un prochain ajout peut deplacer le tableau via realloc.
 * Ne pas conserver ce pointeur apres un ajout ; refaire une recherche. */
Produit *rechercherProduit(Boutique *b, const char *reference);

/* Affiche tout le catalogue, son etat et sa valorisation HT.
 * Les produits desactives restent visibles pour conserver l'historique. */
void afficherProduits(const Boutique *b);

#endif
