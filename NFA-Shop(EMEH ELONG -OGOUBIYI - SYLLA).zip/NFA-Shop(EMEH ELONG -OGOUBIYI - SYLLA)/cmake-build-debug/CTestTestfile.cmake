# CMake generated Testfile for 
# Source directory: /Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)
# Build directory: /Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/cmake-build-debug
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(test_statistique "/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/cmake-build-debug/test_statistique")
set_tests_properties(test_statistique PROPERTIES  _BACKTRACE_TRIPLES "/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/CMakeLists.txt;24;add_test;/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/CMakeLists.txt;0;")
add_test(test_top5 "/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/cmake-build-debug/test_top5")
set_tests_properties(test_top5 PROPERTIES  _BACKTRACE_TRIPLES "/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/CMakeLists.txt;24;add_test;/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/CMakeLists.txt;0;")
add_test(test_commande_original "/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/cmake-build-debug/test_commande_original")
set_tests_properties(test_commande_original PROPERTIES  _BACKTRACE_TRIPLES "/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/CMakeLists.txt;24;add_test;/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/CMakeLists.txt;0;")
add_test(test_integration "/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/cmake-build-debug/test_integration")
set_tests_properties(test_integration PROPERTIES  _BACKTRACE_TRIPLES "/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/CMakeLists.txt;24;add_test;/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/CMakeLists.txt;0;")
add_test(test_favoris "/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/cmake-build-debug/test_favoris")
set_tests_properties(test_favoris PROPERTIES  _BACKTRACE_TRIPLES "/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/CMakeLists.txt;30;add_test;/Users/aboubacarsylla/Documents/projet c (Ndomè , Fadhyl,Aboubacar)/NFA-Shop(EMEH ELONG -OGOUBIYI - SYLLA)/CMakeLists.txt;0;")
