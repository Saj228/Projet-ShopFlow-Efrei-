//
// Created by Aboubacar Sylla on 02/11/2026.
//
#include "favoris.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "types.h"

int main(void)
{
    Produit produits[] = {
        {
            .reference = "PRD-0001",
            .designation = "Clavier",
            .prixUnitaireHT = 50.0f,
            .quantiteStock = 10,
            .actif = 1
        },
        {
            .reference = "PRD-0002",

            .designation = "Souris",
            .prixUnitaireHT = 20.0f,
            .quantiteStock = 5,
            .actif = 1
        },
        {
            .reference = "PRD-0003",
            .designation = "Ecran",
            .actif = 0
        }
    };

    Boutique boutique = {0};
    boutique.produits = produits;
    boutique.nbProduits = 3;

    Client client = {
        .nom = "Sylla",
        .prenom = "Aboubacar",
        .actif = 1
    };

    /* La liste commence vide. */
    afficherFavoris(&boutique, &client);

    /* Ajouter deux produits. */
    assert(ajouterFavori(&boutique, &client, "PRD-0001") == 1);
    assert(ajouterFavori(&boutique, &client, "PRD-0002") == 1);
    assert(client.nbFavoris == 2);

    /* Refuser doublon, produit absent et produit desactive. */
    assert(ajouterFavori(&boutique, &client, "PRD-0001") == 0);
    assert(ajouterFavori(&boutique, &client, "PRD-9999") == 0);
    assert(ajouterFavori(&boutique, &client, "PRD-0003") == 0);

    afficherFavoris(&boutique, &client);

    /* Retirer le clavier : la souris doit rester. */
    assert(retirerFavori(&client, "PRD-0001") == 1);
    assert(estFavori(&client, "PRD-0001") == 0);
    assert(estFavori(&client, "PRD-0002") == 1);
    assert(client.nbFavoris == 1);

    afficherFavoris(&boutique, &client);

    /* Retirer le dernier favori. */
    assert(retirerFavori(&client, "PRD-0002") == 1);
    assert(retirerFavori(&client, "PRD-0002") == 0);
    assert(client.nbFavoris == 0);

    afficherFavoris(&boutique, &client);

    free(client.favoris);

    printf("\nTous les tests favoris ont reussi.\n");

    /* Tester l'agrandissement du tableau avec six favoris. */
    Produit produitsTest[6] = {0};

    for (int i = 0; i < 6; i++) {
        snprintf(produitsTest[i].reference,
                 sizeof produitsTest[i].reference,
                 "PRD-%04d", i + 1);

        produitsTest[i].actif = 1;
    }

    Boutique boutiqueTest = {0};
    boutiqueTest.produits = produitsTest;
    boutiqueTest.nbProduits = 6;

    Client clientTest = {0};
    clientTest.actif = 1;

    for (int i = 0; i < 6; i++) {
        assert(ajouterFavori(&boutiqueTest,
                            &clientTest,
                            produitsTest[i].reference) == 1);
    }

    assert(clientTest.nbFavoris == 6);
    assert(clientTest.capaciteFavoris >= 6);

    /* Verifier que toutes les references sont conservees. */
    for (int i = 0; i < 6; i++) {
        assert(estFavori(&clientTest,
                         produitsTest[i].reference) == 1);
    }

    free(clientTest.favoris);

    printf("Test d'agrandissement des favoris reussi.\n");
    return 0;
}