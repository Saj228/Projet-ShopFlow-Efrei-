// Created by nemeh on 26/10/2026.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "commande.h"
#define TVA 20

/* Recalculer les montants depuis les sous-totaux : remise par palier,
 * TVA sur le HT apres remise, puis ajout des frais de port. */
void calculCommande(Commande *c) {
    int i;

    c->montantBrutHT = 0;
    for (i = 0; i < c->nbLignes; i++) {
        c->montantBrutHT += c->lignes[i].sousTotalHT;
    }

    if (c->montantBrutHT < 100) {
        c->tauxRemise = 0;
        c->montantHT = c->montantBrutHT;
    } else if (c->montantBrutHT >= 100 && c->montantBrutHT < 300) {
        c->tauxRemise = 5;
        c->montantRemise = c->montantBrutHT * c->tauxRemise / 100;
        c->montantHT = c->montantBrutHT - c->montantRemise;
    } else if (c->montantBrutHT >= 300 && c->montantBrutHT < 600) {
        c->tauxRemise = 10;
        c->montantRemise = c->montantBrutHT * c->tauxRemise / 100;
        c->montantHT = c->montantBrutHT - c->montantRemise;
    } else {
        c->tauxRemise = 15;
        c->montantRemise = c->montantBrutHT * c->tauxRemise / 100;
        c->montantHT = c->montantBrutHT - c->montantRemise;
    }

    c->montantTVA = c->montantHT * TVA / 100;
    if (c->montantBrutHT >= 60) {
        c->fraisPort = 0;
    } else {
        c->fraisPort = 5.90;
    }

    c->montantTTC = c->montantHT + c->montantTVA + c->fraisPort;
}

/* Ajouter une ligne au tableau dynamique et recalculer la commande.
 * Cette fonction copie les textes et le prix pour conserver les valeurs d'achat. */
int ajouterLigne(Commande *c, const char *ref, const char *designation,
                 int quantite, float prixHT) {
    int newCap;
    if (c->nbLignes == c->capaciteLignes) {
        if (c->capaciteLignes == 0) {
            newCap = 2;
        } else {
            newCap = c->capaciteLignes * 2;
        }


        /* Garder l'ancien pointeur si realloc echoue ; remplacer seulement apres succes. */
        LigneCommande *tmp = realloc(c->lignes, newCap * sizeof(LigneCommande));
        if (tmp == NULL) {
            return 0;
        }
        c->lignes = tmp;
        c->capaciteLignes = newCap;
    }

    c->lignes[c->nbLignes].quantite = quantite;
    strcpy(c->lignes[c->nbLignes].designation, designation);
    strcpy(c->lignes[c->nbLignes].refProduit, ref);
    c->lignes[c->nbLignes].prixUnitaireHT = prixHT;
    c->lignes[c->nbLignes].sousTotalHT = quantite * prixHT;
    c->nbLignes++;
    calculCommande(c);

    return 1;
}

/* Preparer une commande EN_COURS, sans ligne et sans montant.
 * Le code appelant renseigne ensuite la date et l'adresse de livraison. */
void initialiserCommande(Commande *c, int numero, int idClient) {
    c->idClient = idClient;
    c->numero = numero;
    c->lignes = NULL;
    c->nbLignes = 0;
    c->capaciteLignes = 0;

    c->fraisPort = 0;
    c->montantTVA = 0;
    c->montantTTC = 0;
    c->montantBrutHT = 0;
    c->tauxRemise = 0;
    c->montantRemise = 0;
    c->montantHT = 0;

    strcpy(c->statut, "EN_COURS");
}

/* Liberer uniquement le tableau des lignes, pas la structure Commande. */
void libererCommande(Commande *c) {
    free(c->lignes);
    c->lignes = NULL;
    c->nbLignes = 0;
    c->capaciteLignes = 0;
}

/* Avancer d'une seule etape : EN_COURS -> EXPEDIEE -> LIVREE.
 * Retourner 0 lorsqu'aucune transition n'est possible. */
int changerStatut(Commande *c) {
    if (strcmp(c->statut, "EN_COURS") == 0) {
        strcpy(c->statut, "EXPEDIEE");
        return 1;
    }
    if (strcmp(c->statut, "EXPEDIEE") == 0) {
        strcpy(c->statut, "LIVREE");
        return 1;
    }
    return 0;
}

/* Afficher les lignes et le detail des montants deja calcules. */
void afficherCommande(const Commande *c) {
    int i;
    printf("*Numéro %d*\n", c->numero);
    printf("Client : %d\n", c->idClient);
    printf("Statut : %s\n", c->statut);

    printf("\nProduits : ");
    for (i = 0; i < c->nbLignes; i++) {
        printf("%d x %s %.2f %.2f EUR\n",
               c->lignes[i].quantite, c->lignes[i].designation, c->lignes[i].prixUnitaireHT, c->lignes[i].sousTotalHT);
    }
    printf("Brut : %.2f\n", c->montantBrutHT);
    printf("Remise : %.0f %% (-%.2f)\n", c->tauxRemise, c->montantRemise);
    printf(" Prix HT : %.2f\n", c->montantHT);
    printf("Montant TVA : %.2f\n", c->montantTVA);
    printf("Frais de port : %.2f\n", c->fraisPort);
    printf("Montant total : %.2f\n", c->montantTTC);
}

/* Construire une commande pour un client actif. Les lignes sont preparees
 * avant de diminuer les stocks ; le numero est attribue par la boutique.
 * Retour : numero cree, ou 0 si la creation echoue. */
int creerCommande(Boutique *b, int idClient, Date date,
                  const char *refs[], int quantites[], int nbArticles) {
    int i, j, newCap;
    Client *client = NULL;
    Commande cmd;

    /* 1. chercher le client */
    for (i = 0; i < b->nbClients; i++) {
        if (b->clients[i].idClient == idClient && b->clients[i].actif == 1) {
            client = &b->clients[i];
        }
    }
    if (client == NULL) { return 0; }

    /* 2. préparer la commande */
    initialiserCommande(&cmd, b->numeroSuivant, idClient);
    cmd.dateCommande = date;
    cmd.adresseLivraison = client->adresse;

    /* 3. ajouter les articles */
    for (i = 0; i < nbArticles; i++) {
        if (ajouterProduitCommande(b, &cmd, refs[i], quantites[i]) == 0) {
            libererCommande(&cmd);
            return 0;
        }
    }

    /* 4. refuser une commande vide */
    if (cmd.nbLignes == 0) {
        libererCommande(&cmd);
        return 0;
    }

    /* 5. agrandir le tableau de commandes du client si plein */
    if (client->nbCommandes == client->capaciteCommande) {
        if (client->capaciteCommande == 0) {
            newCap = 2;
        } else {
            newCap = client->capaciteCommande * 2;
        }
        Commande *tmp = realloc(client->commandes, newCap * sizeof(Commande));
        if (tmp == NULL) {
            libererCommande(&cmd);
            return 0;
        }
        client->commandes = tmp;
        client->capaciteCommande = newCap;
    }

    /* 6. valider : stock et points */
    for (i = 0; i < cmd.nbLignes; i++) {
        for (j = 0; j < b->nbProduits; j++) {
            if (strcmp(b->produits[j].reference, cmd.lignes[i].refProduit) == 0) {
                b->produits[j].quantiteStock -= cmd.lignes[i].quantite;
            }
        }
    }
    client->pointsFidelite += (int)(cmd.montantTTC / 10);

    /* 7. ranger la commande chez le client */
    client->commandes[client->nbCommandes] = cmd;
    client->nbCommandes++;
    b->numeroSuivant++;
    return cmd.numero;
}


/* Retrouver un produit actif, refuser les doublons et verifier son stock.
 * L'ajout de la ligne ne diminue pas lui-meme le stock du catalogue. */
int ajouterProduitCommande(Boutique *b, Commande *cmd, const char *ref, int quantite) {
    int i;

    Produit *produit = NULL;

    if (quantite < 1) { return 0; }

    for (i = 0; i < b->nbProduits; i++) {
        if (strcmp(b->produits[i].reference, ref) == 0 && b->produits[i].actif == 1) {
            produit = &b->produits[i];
        }
    }
    if (produit == NULL) { return 0; }
    for (i = 0; i < cmd->nbLignes; i++) {
        if (strcmp(cmd->lignes[i].refProduit, ref) == 0) {
            return 0;
        }
    }
    if (produit->quantiteStock < quantite) { return 0; }
    return ajouterLigne(cmd, produit->reference, produit->designation, quantite, produit->prixUnitaireHT);
}
/* Retirer une ligne par son indice (a partir de 0), puis recalculer.
 * Cette fonction agit sur la commande, sans modifier le stock ni les points. */
int supprimerLigne(Commande *c, int indice) {

        if (c == NULL || c->lignes == NULL)
            return 0;

        if (strcmp(c->statut, "EN_COURS") != 0)
            return 0;

        if (c->nbLignes <= 1)
            return 0;

        if (indice < 0 || indice >= c->nbLignes)
            return 0;

        for (int i = indice; i < c->nbLignes - 1; i++)
            c->lignes[i] = c->lignes[i + 1];

        c->nbLignes--;

        calculCommande(c);
        return 1;
    }
/* Pour une commande EN_COURS, restituer les quantites au catalogue
 * puis passer le statut a ANNULEE. Les points ne sont pas modifies ici. */
int annulerCommande(Boutique *b, Commande *c) {

        if (b == NULL || c == NULL)
            return 0;

        if (strcmp(c->statut, "EN_COURS") != 0)
            return 0;

        for (int i = 0; i < c->nbLignes; i++)
        {
            for (int j = 0; j < b->nbProduits; j++)
            {
                if (strcmp(b->produits[j].reference,
                           c->lignes[i].refProduit) == 0)
                {
                    b->produits[j].quantiteStock += c->lignes[i].quantite;
                    break;
                }
            }
        }

        strcpy(c->statut, "ANNULEE");
        return 1;


}

