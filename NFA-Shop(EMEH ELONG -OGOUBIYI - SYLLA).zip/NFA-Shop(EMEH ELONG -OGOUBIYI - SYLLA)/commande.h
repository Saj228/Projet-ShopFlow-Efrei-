//
// Created by nemeh on 26/10/2026.
//

#ifndef SHOPFLOW_COMMANDE_H
#define SHOPFLOW_COMMANDE_H

#include "types.h"
#define TVA 20

void calculCommande(Commande *c);

int ajouterLigne(Commande *c, const char *ref, const char *designation,int quantite, float prixHT);

void initialiserCommande(Commande *c,int numero,int idClient);

void libererCommande(Commande *c);

int changerStatut(Commande *c);

void afficherCommande(const Commande *c);

int creerCommande(Boutique *b, int idClient, Date date,const char *refs[], int quantites[], int nbArticles);

int ajouterProduitCommande(Boutique *b, Commande *cmd, const char *ref, int quantite);

int supprimerLigne(Commande *c, int indice);

int annulerCommande(Boutique *b, Commande *c);


#endif //SHOPFLOW_COMMANDE_H
