//
// Created by nemeh on 26/10/
#ifndef SHOPFLOW_TYPES_H
#define SHOPFLOW_TYPES_H

//alors nous avons fait nos structures,
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    int jour ;
    int mois ;
    int annee;
}Date;

#define TAILLE_rue 80
#define TAILLE_ville 50
#define Postal 6
#define TAILLE_Pays 50

typedef struct {
    char Rue[TAILLE_rue];
    char Ville[TAILLE_ville];
    char codePostal[Postal];
    char Pays[TAILLE_Pays] ;
}Adresse;

#define TAILLE_REF 12
#define NAME_PRODUIT 60
#define TAILLE_CATEGORIE 30

typedef struct  {
    char reference[TAILLE_REF];
    char designation[NAME_PRODUIT];
    char categorie[TAILLE_CATEGORIE];
    float prixUnitaireHT;
    int quantiteStock;
    int seuilAlerte;
    int actif;
}Produit ;

#define TAILLE_DES 60

typedef struct  {
    char refProduit[TAILLE_REF];
    char designation [TAILLE_DES];
    int quantite ;
    float prixUnitaireHT;
    float sousTotalHT;
}LigneCommande;

#define ETAT_STATUT 20

typedef struct  {
    int numero;
    int idClient ;
    Date dateCommande ;
    char statut[ETAT_STATUT];
    int nbLignes ;
    int capaciteLignes;
    LigneCommande *lignes ; /*Ligne commande*/
    float montantBrutHT;
    float tauxRemise ;
    float montantRemise ;
    float montantHT;
    float montantTVA;
    float montantTTC;
    float fraisPort;
    Adresse adresseLivraison ;/*adresseLivraison*/

}Commande;

#define TAILLE_NOM 50
#define TAILLE_PRENOM 50
#define TAILLE_EMAIL 80
#define TAILLE_PHONE 15

/* Constantes supplementaires du fichier Sylla : noms existants conserves. */
#define TAILLE_RUE TAILLE_rue
#define TAILLE_VILLE TAILLE_ville
#define TAILLE_CODE_POSTAL Postal
#define TAILLE_PAYS TAILLE_Pays
#define TAILLE_DESIGNATION NAME_PRODUIT
#define TAILLE_STATUT ETAT_STATUT
#define TAILLE_REFERENCE 30

typedef struct {
    int idClient;
    char nom[TAILLE_NOM];
    char prenom[TAILLE_PRENOM];
    char email[TAILLE_EMAIL];
    char telephone[TAILLE_PHONE];
    int pointsFidelite;
    int capaciteCommande;
    /* Historique dynamique : nbCommandes elements utilises sur capaciteCommande. */
    Commande *commandes;
    int actif;
    Adresse adresse;
    int nbCommandes;

    /* Favoris : tableau dynamique de references de produits. */
    char (*favoris)[TAILLE_REF];
    /* Nombre utilise ; la capacite indique le nombre d'emplacements alloues. */
    int nbFavoris;
    int capaciteFavoris;

}Client;

#define NAME 50

typedef struct {
    char NOM[NAME];
    Produit *produits;
    int nbProduits;
    int capaciteClients;
    Client *clients;
    int nbClients;
    int numeroSuivant;
    int idClientSuivant;
    int capaciteProduits;




}Boutique; /*structure racine*/

/* Structures supplementaires pour les classements statistiques. */
typedef struct {
    const Client *client;
    float chiffreAffaires;
}ResultatClient;

typedef struct {
    const Produit *produit;
    int quantiteVendue;
}ResultatProduit;

#endif //SHOPFLOW_TYPES_H
