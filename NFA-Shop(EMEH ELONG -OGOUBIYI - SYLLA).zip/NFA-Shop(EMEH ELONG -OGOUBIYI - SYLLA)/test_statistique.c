
// Created by Aboubacar Sylla on 28/10/2026.
//
#include <stdio.h>
#include "statistique.h"

int main(void)
{
    /*Deux commandes : livree et une annulee.*/
    Commande commandes[] = {
        {
            .dateCommande = {10,10,2026},
            .statut = "LIVREE",
            .montantHT =100.0f,
            .montantTTC =120.0f
        },
        {
            .dateCommande = {15,10,2026},
            .statut = "ANNULEE",
            .montantHT =50.0f,
            .montantTTC =60.0f
        },
        {
            .dateCommande = {5,11,2026},
            .statut = "LIVREE",
            .montantHT = 200.0f,
            .montantTTC = 240.0f
        }
    };

    Client client = {0};
    client.commandes = commandes;
    client.nbCommandes = 3;
    client.capaciteCommande = 3;

    Boutique boutique ={0};
    boutique.clients = &client;
    boutique.nbClients = 1;
    boutique.capaciteClients = 1;


    printf("CA HT : %.2f euros\n" , calculerChiffreAffairesHT(&boutique));

    printf("CA TTC : %.2f euros\n" , calculerChiffreAffairesTTC(&boutique));

    printf("CA HT octobre 2026 : %.2f euros\n" , calculerChiffreAffairesHTParMois(&boutique,10,2026));

    printf("CA HT septembre 2026 : %.2f euros\n" , calculerChiffreAffairesHTParMois(&boutique,9,2026));

    printf("CA HT octobre 2025 : %.2f euros\n" , calculerChiffreAffairesHTParMois(&boutique,10,2025));

    printf("CA TTC octobre 2026 : %.2f euros\n", calculerChiffreAffairesTTCParMois(&boutique, 10, 2026));

    printf("CA TTC septembre 2026 : %.2f euros\n", calculerChiffreAffairesTTCParMois(&boutique, 9, 2026));

    printf("CA TTC octobre 2025 : %.2f euros\n", calculerChiffreAffairesTTCParMois(&boutique, 10, 2025));

    printf("CA HT annee 2026 : %.2f euros\n" , calculerChiffreAffairesHTParAnnee(&boutique,2026));

    printf("CA TTC annee 2026 : %.2f euros\n", calculerChiffreAffairesTTCParAnnee(&boutique, 2026));

    printf("CA HT annee 2025 : %.2f euros\n", calculerChiffreAffairesHTParAnnee(&boutique, 2025));

    printf("CA TTC annee 2025 : %.2f euros\n", calculerChiffreAffairesTTCParAnnee(&boutique, 2025));

    printf("CA HT novembre 2026 : %.2f euros\n", calculerChiffreAffairesHTParMois(&boutique, 11, 2026));

    printf("CA TTC novembre 2026 : %.2f euros\n", calculerChiffreAffairesTTCParMois(&boutique, 11, 2026));

    printf("CA TTC du client : %.2f euros\n", calculerChiffreAffairesClientTTC(&client));

    /* Donner une identite au client du test. */
    client.idClient = 1;

    snprintf(client.prenom, sizeof client.prenom, "Aboubacar");

    snprintf(client.nom, sizeof client.nom, "Sylla");

    afficherClassementClients(&boutique);

    /* Une commande pour le deuxieme client. */
    Commande commandeFadhyl = {
        .dateCommande = {20, 10, 2026},
        .statut = "LIVREE",
        .montantHT = 500.0f,
        .montantTTC = 600.0f
    };

    Client fadhyl = {0};
    fadhyl.idClient = 2;

    snprintf(fadhyl.prenom, sizeof fadhyl.prenom, "Fadhyl");
    snprintf(fadhyl.nom, sizeof fadhyl.nom, "Test");

    fadhyl.commandes = &commandeFadhyl;
    fadhyl.nbCommandes = 1;
    fadhyl.capaciteCommande = 1;

    /* Aboubacar est volontairement place en premier avant le tri. */
    Client clientsTest[] = {client, fadhyl};

    Boutique boutiqueTest = {0};
    boutiqueTest.clients = clientsTest;
    boutiqueTest.nbClients = 2;
    boutiqueTest.capaciteClients = 2;

    printf("\n--- Test du tri avec deux clients ---\n");
    afficherClassementClients(&boutiqueTest);

    /* Lignes de test pour les trois commandes d'Aboubacar. */
    LigneCommande lignesTest[] = {
        {
            .refProduit = "PRD-0001",
            .designation = "Clavier",
            .quantite = 2,
            .prixUnitaireHT = 50.0f,
            .sousTotalHT = 100.0f
        },
        {
            .refProduit = "PRD-0001",
            .designation = "Clavier",
            .quantite = 10,
            .prixUnitaireHT = 5.0f,
            .sousTotalHT = 50.0f
        },
        {
            .refProduit = "PRD-0001",
            .designation = "Clavier",
            .quantite = 4,
            .prixUnitaireHT = 50.0f,
            .sousTotalHT = 200.0f
        }
    };

    for (int i = 0; i < 3; i++) {
        commandes[i].lignes = &lignesTest[i];
        commandes[i].nbLignes = 1;
        commandes[i].capaciteLignes = 1;
    }

    printf("Quantite vendue PRD-0001 : %d\n",
           calculerQuantiteVendue(&boutique, "PRD-0001"));

    printf("Quantite vendue PRD-9999 : %d\n",
           calculerQuantiteVendue(&boutique, "PRD-9999"));

    /* Catalogue de test : le clavier est volontairement en premier. */
    Produit produitsTest[] = {
        {
            .reference = "PRD-0001",
            .designation = "Clavier",
            .categorie = "Informatique",
            .prixUnitaireHT = 50.0f,
            .actif = 1
        },
        {
            .reference = "PRD-0002",
            .designation = "Souris",
            .categorie = "Informatique",
            .prixUnitaireHT = 10.0f,
            .actif = 1
        }
    };

    boutique.produits = produitsTest;
    boutique.nbProduits = 2;
    boutique.capaciteProduits = 2;

    /* Remplacer les lignes de la premiere commande.
       Son montant brut reste 100 euros : 20 + 80. */
    LigneCommande lignesPremiereCommande[] = {
        {
            .refProduit = "PRD-0001",
            .designation = "Clavier",
            .quantite = 2,
            .prixUnitaireHT = 10.0f,
            .sousTotalHT = 20.0f
        },
        {
            .refProduit = "PRD-0002",
            .designation = "Souris",
            .quantite = 8,
            .prixUnitaireHT = 10.0f,
            .sousTotalHT = 80.0f
        }
    };

    commandes[0].lignes = lignesPremiereCommande;
    commandes[0].nbLignes = 2;
    commandes[0].capaciteLignes = 2;

    afficherTop5Produits(&boutique);

    return 0;
}