//
// Created by Aboubacar Sylla on 31/10/2026.
//
#include <stdio.h>
#include <string.h>

#include "statistique.h"

int main(void)
{
    /* Tableaux fixes uniquement pour ce test. */
    Produit produits[6] = {0};
    LigneCommande lignes[6] = {0};

    for (int i = 0; i < 6; i++) {
        snprintf(produits[i].reference,
                 sizeof produits[i].reference,
                 "PRD-%04d", i + 1);

        snprintf(produits[i].designation,
                 sizeof produits[i].designation,
                 "Produit %d", i + 1);

        strcpy(produits[i].categorie, "Test");
        produits[i].prixUnitaireHT = 10.0f;
        produits[i].actif = 1;

        strcpy(lignes[i].refProduit, produits[i].reference);
        strcpy(lignes[i].designation, produits[i].designation);

        lignes[i].quantite = i + 1;
        lignes[i].prixUnitaireHT = 10.0f;
        lignes[i].sousTotalHT = (i + 1) * 10.0f;
    }

    Commande commande = {0};
    strcpy(commande.statut, "LIVREE");
    commande.lignes = lignes;
    commande.nbLignes = 6;
    commande.capaciteLignes = 6;

    Client client = {0};
    client.commandes = &commande;
    client.nbCommandes = 1;
    client.capaciteCommande = 1;

    Boutique boutique = {0};
    boutique.produits = produits;
    boutique.nbProduits = 6;
    boutique.capaciteProduits = 6;
    boutique.clients = &client;
    boutique.nbClients = 1;
    boutique.capaciteClients = 1;

    printf("\n--- TEST 1 : six produits vendus ---\n");
    afficherTop5Produits(&boutique);

    printf("\n--- TEST 2 : commande annulee ---\n");
    strcpy(commande.statut, "ANNULEE");
    afficherTop5Produits(&boutique);

    printf("\n--- TEST 3 : boutique vide ---\n");
    Boutique boutiqueVide = {0};
    afficherTop5Produits(&boutiqueVide);

    return 0;
}