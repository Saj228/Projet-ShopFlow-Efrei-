/* Menu d'integration : appels aux modules disponibles.
 * La gestion interactive des clients et le cycle complet des commandes
 * seront branches quand les modules de Fadhyl et Ndome seront termines. */
#include "produit.h"
#include "commande.h"
#include "statistique.h"
#include "initialisation.h"
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Ces saisies sont locales au menu. A remplacer ensuite par les fonctions
 * communes de utils.c lorsque leur interface sera validee par le groupe. */
static int lireTexte(const char *message, char *texte, size_t taille)
{
    for (;;) {
        printf("%s", message);
        fflush(stdout);
        if (fgets(texte, (int)taille, stdin) == NULL) return 0;
        char *fin = strchr(texte, '\n');
        if (fin != NULL) *fin = '\0';
        else {
            int c = getchar();
            if (c != '\n' && c != EOF) {
                while ((c = getchar()) != '\n' && c != EOF) { }
                printf("Texte trop long (maximum %zu caracteres).\n", taille - 1);
                continue;
            }
        }
        int nonVide = 0;
        for (size_t i = 0; texte[i] != '\0'; i++) {
            if (!isspace((unsigned char)texte[i])) nonVide = 1;
        }
        if (nonVide) return 1;
        printf("Saisie vide : recommencez.\n");
    }
}

/* Convertir la saisie et verifier qu'elle respecte les bornes du menu. */
static int lireEntier(const char *message, int minimum, int maximum, int *valeur)
{
    char texte[80];
    while (lireTexte(message, texte, sizeof texte)) {
        char *fin;
        errno = 0;
        long nombre = strtol(texte, &fin, 10);
        while (isspace((unsigned char)*fin)) fin++;
        if (errno == 0 && fin != texte && *fin == '\0'
            && nombre >= minimum && nombre <= maximum) {
            *valeur = (int)nombre;
            return 1;
        }
        printf("Entrez un entier entre %d et %d.\n", minimum, maximum);
    }
    return 0;
}

/* Accepter le point ou la virgule, puis exiger un prix fini et positif. */
static int saisirPrix(float *prix)
{
    char texte[80];
    while (lireTexte("Prix HT (exemple 19.90) : ", texte, sizeof texte)) {
        char *fin;
        for (size_t i = 0; texte[i] != '\0'; i++) {
            if (texte[i] == ',') texte[i] = '.';
        }
        errno = 0;
        float valeur = strtof(texte, &fin);
        while (isspace((unsigned char)*fin)) fin++;
        if (errno == 0 && fin != texte && *fin == '\0'
            && isfinite(valeur) && valeur > 0.0f) {
            *prix = valeur;
            return 1;
        }
        puts("Le prix doit etre un nombre fini strictement positif.");
    }
    return 0;
}

/* Rassembler les donnees avant de demander au module produit de les enregistrer. */
static void saisirProduit(Boutique *b)
{
    Produit p = {0};
    if (!lireTexte("Reference : ", p.reference, sizeof p.reference)
        || !lireTexte("Designation : ", p.designation, sizeof p.designation)
        || !lireTexte("Categorie : ", p.categorie, sizeof p.categorie)
        || !saisirPrix(&p.prixUnitaireHT)
        || !lireEntier("Stock : ", 0, INT_MAX, &p.quantiteStock)
        || !lireEntier("Seuil d'alerte : ", 0, INT_MAX, &p.seuilAlerte)) return;
    puts(ajouterProduit(b, p) ? "Produit ajoute."
         : "Ajout refuse : reference deja utilisee, donnees invalides ou memoire insuffisante.");
}

static void chercherProduit(Boutique *b)
{
    char ref[TAILLE_REF];
    if (!lireTexte("Reference exacte : ", ref, sizeof ref)) return;
    const Produit *p = rechercherProduit(b, ref);
    if (p == NULL) puts("Produit introuvable.");
    else printf("%s - %s | %.2f EUR HT | Stock : %d | %s\n",
                p->reference, p->designation, p->prixUnitaireHT,
                p->quantiteStock, p->actif ? "actif" : "desactive");
}

/* Affichage provisoire des donnees de demonstration, sans modifier les clients. */
static void afficherClientsDemo(const Boutique *b)
{
    if (b->nbClients == 0) puts("Aucun client.");
    for (int i = 0; i < b->nbClients; i++) {
        const Client *c = &b->clients[i];
        printf("%d - %s %s | %s | %d commande(s) | %d points | CA TTC : %.2f EUR\n",
               c->idClient, c->prenom, c->nom, c->email, c->nbCommandes,
               c->pointsFidelite, calculerChiffreAffairesClientTTC(c));
    }
}

/* Parcourir la boutique : clients, commandes de chaque client, puis lignes. */
static void afficherCommandesDemo(const Boutique *b)
{
    int nombre = 0;
    for (int i = 0; i < b->nbClients; i++) {
        const Client *client = &b->clients[i];
        for (int j = 0; j < client->nbCommandes; j++) {
            const Commande *c = &client->commandes[j];
            nombre++;
            printf("\nCommande %d | Client %d (%s %s) | %02d/%02d/%04d | %s\n",
                   c->numero, c->idClient, client->prenom, client->nom,
                   c->dateCommande.jour, c->dateCommande.mois,
                   c->dateCommande.annee, c->statut);
            for (int k = 0; k < c->nbLignes; k++) {
                const LigneCommande *l = &c->lignes[k];
                printf("  %s - %s : %d x %.2f = %.2f EUR HT\n",
                       l->refProduit, l->designation, l->quantite,
                       l->prixUnitaireHT, l->sousTotalHT);
            }
            printf("Brut HT : %.2f | Remise %.0f %% : %.2f | HT : %.2f\n"
                   "TVA : %.2f | Port : %.2f | TTC : %.2f EUR\n",
                   c->montantBrutHT, c->tauxRemise, c->montantRemise,
                   c->montantHT, c->montantTVA, c->fraisPort, c->montantTTC);
        }
    }
    if (nombre == 0) puts("Aucune commande.");
}

/* Une alerte concerne un produit actif dont le stock atteint ou passe sous le seuil. */
static void afficherAlertes(const Boutique *b)
{
    int nombre = 0;
    for (int i = 0; i < b->nbProduits; i++) {
        const Produit *p = &b->produits[i];
        if (p->actif && p->quantiteStock <= p->seuilAlerte) {
            printf("%s - %s | Stock : %d | Seuil : %d\n",
                   p->reference, p->designation, p->quantiteStock, p->seuilAlerte);
            nombre++;
        }
    }
    if (nombre == 0) puts("Aucune alerte de stock.");
}

int main(int argc, char **argv)
{
    Boutique boutique = {0};
    if (argc == 2 && strcmp(argv[1], "--vide") == 0) {
        snprintf(boutique.NOM, sizeof boutique.NOM, "ShopFlow");
        boutique.numeroSuivant = 1001;
        boutique.idClientSuivant = 1;
    } else if (argc != 1) {
        fprintf(stderr, "Utilisation : %s [--vide]\n", argv[0]);
        return EXIT_FAILURE;
    } else if (!initialiserDonneesTest(&boutique)) {
        fprintf(stderr, "Impossible de charger les donnees de demonstration.\n");
        return EXIT_FAILURE;
    }

    puts("ShopFlow - version d'integration en cours");
    puts("Clients : demonstration en lecture seule, module de Fadhyl a integrer.");
    puts("Commandes : consultation ; creation interactive et statuts a terminer.");
    for (;;) {
        puts("\n1. Afficher les produits\n2. Ajouter un produit\n3. Rechercher un produit"
             "\n4. Consulter les clients de demonstration\n5. Consulter les commandes"
             "\n6. Chiffre d'affaires global\n7. Chiffre d'affaires par mois"
             "\n8. Chiffre d'affaires par annee\n9. Classement des clients"
             "\n10. Top 5 des produits\n11. Alertes de stock\n0. Quitter");
        int choix;
        if (!lireEntier("Votre choix : ", 0, 11, &choix) || choix == 0) break;
        int mois, annee;
        /* Chaque choix delegue l'action au module ou a l'affichage correspondant. */
        switch (choix) {
        case 1: afficherProduits(&boutique); break;
        case 2: saisirProduit(&boutique); break;
        case 3: chercherProduit(&boutique); break;
        case 4: afficherClientsDemo(&boutique); break;
        case 5: afficherCommandesDemo(&boutique); break;
        case 6:
            printf("CA global HT : %.2f EUR | TTC : %.2f EUR\n",
                   calculerChiffreAffairesHT(&boutique),
                   calculerChiffreAffairesTTC(&boutique));
            break;
        case 7:
            if (lireEntier("Mois (1-12) : ", 1, 12, &mois)
                && lireEntier("Annee (2000-2100) : ", 2000, 2100, &annee)) {
                printf("CA %02d/%d HT : %.2f EUR | TTC : %.2f EUR\n", mois, annee,
                       calculerChiffreAffairesHTParMois(&boutique, mois, annee),
                       calculerChiffreAffairesTTCParMois(&boutique, mois, annee));
            }
            break;
        case 8:
            if (lireEntier("Annee (2000-2100) : ", 2000, 2100, &annee)) {
                printf("CA %d HT : %.2f EUR | TTC : %.2f EUR\n", annee,
                       calculerChiffreAffairesHTParAnnee(&boutique, annee),
                       calculerChiffreAffairesTTCParAnnee(&boutique, annee));
            }
            break;
        case 9: afficherClassementClients(&boutique); break;
        case 10: afficherTop5Produits(&boutique); break;
        case 11: afficherAlertes(&boutique); break;
        }
    }
    /* Le menu et les fonctions partagent la meme boutique jusqu'a sa destruction. */
    detruireBoutique(&boutique);
    puts("Fin du programme. Memoire de la boutique liberee.");
    return EXIT_SUCCESS;
}
