# NFA-Shop — Gestion d’une boutique en C

NFA-Shop est un mini-projet de programmation en langage C, réalisé dans le cadre
du cours XTI101 à l’EFREI par **Ndomè Emeh Elong, Fadhyl Ogoubiyi et Aboubacar Sylla**.
Le programme porte également le nom **ShopFlow** dans le code et dans son exécutable.

Le projet représente le fonctionnement d’une boutique : un catalogue de produits,
des clients avec leurs coordonnées et des commandes composées de plusieurs articles.
Il permet de consulter l’activité commerciale à travers le chiffre d’affaires,
les classements de ventes et les alertes de stock. Un module de favoris permet
également d’enregistrer les références des produits préférés d’un client.

L’application s’utilise **dans le terminal**, avec un menu numéroté. Les données
sont conservées en mémoire pendant l’exécution : il n’y a ni base de données,
ni sauvegarde sur disque. Au démarrage, un jeu de démonstration est chargé pour
présenter les fonctionnalités sans saisir toutes les données manuellement.

## Ce que permet le menu fourni

| Choix | Action |
| --- | --- |
| 1 | Afficher le catalogue, les stocks et leur valeur HT |
| 2 | Ajouter un produit avec contrôle de la référence et des données |
| 3 | Rechercher un produit par sa référence exacte |
| 4 | Consulter les clients de démonstration et leur chiffre d’affaires |
| 5 | Consulter les commandes, leurs lignes et leurs montants |
| 6 | Afficher le chiffre d’affaires global HT et TTC |
| 7 | Afficher le chiffre d’affaires d’un mois et d’une année |
| 8 | Afficher le chiffre d’affaires d’une année |
| 9 | Classer les clients par chiffre d’affaires TTC |
| 10 | Afficher les cinq produits les plus vendus |
| 11 | Afficher les produits actifs en alerte de stock |
| 0 | Quitter le programme |

Les modules contiennent également des fonctions de gestion des clients,
de création et de traitement des commandes et de favoris. Dans le menu présent
dans ce dossier, ces actions ne sont pas encore proposées : les clients et
commandes y sont consultables, et les favoris possèdent un programme de test séparé.

## Organisation du code

| Fichier | Rôle |
| --- | --- |
| `types.h` | Structures partagées : Date, Adresse, Produit, LigneCommande, Commande, Client et Boutique |
| `main.c` | Point d’entrée, saisies du menu et appels aux modules |
| `produit.c` / `produit.h` | Ajout, recherche et affichage des produits ; valorisation du stock |
| `client.c` / `client.h` | Saisie, recherche, modification et désactivation des clients dans le tableau propre au module |
| `commande.c` / `commande.h` | Construction des commandes, lignes, montants, progression des statuts et annulation |
| `statistique.c` / `statistique.h` | Chiffres d’affaires HT/TTC, classement des clients et top 5 des produits |
| `favoris.c` / `favoris.h` | Ajout, retrait et consultation des favoris par référence |
| `Utils.c` / `Utils.h` | Fonctions de saisie, validation des coordonnées et affichage formaté |
| `initialisation.c` / `initialisation.h` | Chargement des données de démonstration et destruction des allocations de la boutique |
| `test_*.c` | Programmes indépendants de vérification des modules |

Les fichiers `.h` décrivent les interfaces ; les fichiers `.c` contiennent les
implémentations. Les données de démonstration sont regroupées dans une `Boutique` :
elle contient les produits et les clients ; chaque client possède ses commandes,
et chaque commande possède ses lignes. Les favoris mémorisent des références
plutôt que des pointeurs vers des produits susceptibles de changer d’adresse.

## Règles de calcul

Le montant HT brut est la somme des sous-totaux des lignes, obtenus en multipliant
la quantité par le prix unitaire enregistré lors de la commande.

| Montant HT brut | Remise |
| --- | --- |
| Moins de 100 € | 0 % |
| De 100 € à moins de 300 € | 5 % |
| De 300 € à moins de 600 € | 10 % |
| À partir de 600 € | 15 % |

La TVA est de **20 % du montant HT après remise**. Les frais de port sont de
**5,90 €**, offerts à partir de **60 € HT brut**. Le total TTC additionne le HT
après remise, la TVA et les frais de port. Lors de la création d’une commande,
les points de fidélité sont calculés par partie entière du total TTC divisé par 10.
Les commandes au statut `ANNULEE` sont exclues des calculs statistiques.

## Données de démonstration

Le démarrage normal prépare :

- 8 produits répartis dans 4 catégories, avec plusieurs stocks en alerte ;
- 5 clients fictifs avec coordonnées et adresses ;
- 6 commandes couvrant `EN_COURS`, `EXPEDIEE`, `LIVREE` et `ANNULEE` ;
- deux commandes comportant trois lignes et une commande dépassant 600 € HT brut.

Les commandes conservent une copie de l’adresse de livraison, de la désignation
et du prix des articles au moment de l’achat. Les tableaux des produits, des
clients de démonstration, des commandes et des lignes sont alloués dynamiquement.

## Compiler et lancer

Ouvrir un terminal **dans le dossier qui contient ce README et le Makefile**.
Un compilateur C (`cc`, Clang ou GCC) et Make doivent être installés.

```sh
make -B
./ShopFlow
```

Pour lancer une boutique vide :

```sh
./ShopFlow --vide
```

Pour compiler directement le programme principal sans Make :

```sh
cc -std=c11 -Wall -Wextra -Wpedantic main.c produit.c commande.c statistique.c initialisation.c -o ShopFlow
./ShopFlow
```

Dans CLion, le terminal intégré permet d’exécuter ces mêmes commandes. La
configuration CMake livrée doit être actualisée avant d’utiliser ses cibles de
tests : elle référence un dossier `tests/` absent de cette archive et mélange
`test_favoris.c` avec les autres programmes de test. Chaque test ayant son propre
`main`, il doit être compilé séparément.

Le Makefile actuel compile le menu et les modules produits, commandes,
statistiques et initialisation. Les modules clients, favoris et Utils ne sont
pas tous reliés par cette commande ; leur présence dans le dossier ne signifie
pas que toutes leurs actions sont accessibles dans le menu.

## Tester les favoris séparément

Les fichiers de test se trouvent à la racine du dossier :

```sh
cc -std=c11 -Wall -Wextra -Wpedantic test_favoris.c favoris.c -o test_favoris
./test_favoris
```

Ce test vérifie l’ajout, le refus des doublons et des produits indisponibles,
le retrait, la liste vide et l’agrandissement du tableau au-delà de quatre favoris.
Les instructions `assert` arrêtent le test lorsqu’une condition attendue est fausse.

## Objectifs pédagogiques

Ce projet met en pratique les structures imbriquées, les pointeurs, l’allocation
dynamique, les chaînes de caractères et les algorithmes de parcours et de tri.
Le découpage en modules permet de répartir le travail entre les membres du groupe
et d’expliquer séparément les produits, les clients, les commandes et les statistiques.
