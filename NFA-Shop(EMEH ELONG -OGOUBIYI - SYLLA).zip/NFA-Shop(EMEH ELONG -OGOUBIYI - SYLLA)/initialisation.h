#ifndef SHOPFLOW_INITIALISATION_H
#define SHOPFLOW_INITIALISATION_H
#include "types.h"
/* Recevoir une boutique vide : Boutique b = {0};
 * En cas d'echec, toute la memoire partiellement allouee est liberee. */
int initialiserDonneesTest(Boutique *b);
void detruireBoutique(Boutique *b);
#endif
