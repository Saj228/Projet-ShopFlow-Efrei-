#include <stdio.h>
#include <string.h>
#include "types.h"
#include "client.h"
#define TAILLE_TAB_C 200

/* Stockage propre a ce module : distinct du tableau Boutique.clients
 * utilise par le menu et les donnees de demonstration. */
 Client clients [TAILLE_TAB_C];
    int nombreClients = 0;
Adresse adrclient;
int j;
/* Saisir les coordonnees. Dans cette version, clients-> designe clients[0]. */
void ajouterClient(void)
{
    printf("Veuillez attribuez une ID au client: ");
    scanf("%d", &clients->idClient); 
   // Vider le buffer jusqu'au saut de ligne
        int c;
        while ((c = getchar()) != '\n' && c != EOF);
    printf("Entrez le nom du client: ");
    fgets(clients->nom, sizeof(clients->nom), stdin);
    printf("Entrez le prenom du client: ");
    fgets(clients->prenom, sizeof(clients->prenom), stdin);
        do{
    printf("Saisissez le mail du client: ");
    fgets(clients->email, sizeof(clients->email), stdin);
            if (strchr(clients->email, '@') == NULL) 
            {
                printf("Votre adresse mail doit contenir un @ !\n");
            }
        } while (strchr(clients->email, '@') == NULL);
    printf("Entrez le numero de telephone du client (Veuillez entrez uniquement des chiffres): ");
    fgets(clients->telephone, sizeof(clients->telephone), stdin);
    printf("Accordez des points de fidelite au client: ");
    scanf("%d", &clients->pointsFidelite);
    printf("\nCommencons par entrer l'adresse du cient\n");
    /*Adresse adrclient;*/
    int z;
        while ((z = getchar()) != '\n' && z != EOF);
    printf("Veuillez entrez l'adresse de la rue: ");
    fgets(adrclient.Rue, sizeof(adrclient.Rue), stdin);
    printf("Entrez la ville: ");
    fgets(adrclient.Ville, sizeof(adrclient.Ville), stdin);
    printf("Entrez le code postale de votre ville: ");
    fgets(adrclient.codePostal, sizeof(adrclient.codePostal), stdin);
    printf("Enfin entrez le pays: ");
    fgets(adrclient.Pays, sizeof(adrclient.Pays), stdin); 
    /*clients->adr = adrclient;*/                 
}

/* Rechercher par identifiant dans le tableau global et afficher la fiche trouvee. */
void afficherListeClients(void)
{
    int id_de_recherche;
    printf("Veuillez entrez l'id du client recherche: ");
    scanf("%d", &id_de_recherche);
                for(j = 0; j <= TAILLE_TAB_C; j++)
                    {  
                        if (id_de_recherche == clients[j].idClient)
                            {
                                printf("\n");
                                printf("ID : %d\n", id_de_recherche);
                                printf("Nom du client : %s\n", clients[j].nom);
                                printf("Prenom du client : %s\n", clients[j].prenom);
                                printf("Email client : %s\n", clients[j].email);
                                printf("Telephone du client : %s\n", clients[j].telephone);
                                printf("Les points de fidelite du client : %d\n", clients[j].pointsFidelite);
                                printf("Adresse du client : %s,%s,%s,%s", clients[j].adresse.Rue,clients[j].adresse.Ville,clients[j].adresse.codePostal,clients[j].adresse.Pays);
                            }
                            
                    }
}


/* Rechercher un identifiant, puis modifier le champ choisi par l'utilisateur. */
    void modifierClient(void)
{
    int id_recherche;
    int trouve = 0;
    int choix;
    int j;

    printf("Entrez l'ID du client a modifier : ");
    scanf("%d", &id_recherche);

    // Rechercher le client
    for (j = 0; j < TAILLE_TAB_C; j++)
    {
        if (clients[j].idClient == id_recherche)
        {
            trouve = 1;
            break;
        }
    }

    if (trouve == 0)
    {
        printf("Aucun client associe a cet ID !\n");
        return;
    }

    // Afficher les informations du client
    printf("\nClient trouve : %s %s\n",
           clients[j].nom, clients[j].prenom);

    printf("\nQuelle information voulez-vous modifier ?\n");
    printf("1. Nom\n");
    printf("2. Prenom\n");
    printf("3. Email\n");
    printf("4. Telephone\n");
    printf("5. Points de fidelite\n");
    printf("6. Adresse\n");
    printf("Votre choix : ");

    scanf("%d", &choix);

    // Vider le buffer
    int c;
    while ((c = getchar()) != '\n' && c != EOF);

    switch (choix)
    {
        case 1:
            printf("Nouveau nom : ");
            fgets(clients[j].nom, sizeof(clients[j].nom), stdin);
            break;

        case 2:
            printf("Nouveau prenom : ");
            fgets(clients[j].prenom, sizeof(clients[j].prenom), stdin);
            break;

        case 3:
            do
            {
                printf("Nouvel email : ");
                fgets(clients[j].email, sizeof(clients[j].email), stdin);

                if (strchr(clients[j].email, '@') == NULL)
                {
                    printf("L'email doit contenir un @ !\n");
                }

            } while (strchr(clients[j].email, '@') == NULL);
            break;

        case 4:
            printf("Nouveau telephone : ");
            fgets(clients[j].telephone, sizeof(clients[j].telephone), stdin);
            break;

        case 5:
            printf("Nouveaux points de fidelite : ");
            scanf("%d", &clients[j].pointsFidelite);
            break;

        case 6:
            printf("Nouvelle rue : ");
            fgets(clients[j].adresse.Rue, sizeof(clients[j].adresse.Rue), stdin);

            printf("Nouvelle ville : ");
            fgets(clients[j].adresse.Ville, sizeof(clients[j].adresse.Ville), stdin);

            printf("Nouveau code postal : ");
            fgets(clients[j].adresse.codePostal, sizeof(clients[j].adresse.codePostal), stdin);

            printf("Nouveau pays : ");
            fgets(clients[j].adresse.Pays, sizeof(clients[j].adresse.Pays), stdin);
            break;

        default:
            printf("Choix invalide !\n");
            return;
    }

    printf("\nModification effectuee avec succes !\n");
}

/* Suppression logique : desactiver le client sans effacer son enregistrement. */
void supprimerClient(void)
{
    int id_recherche;
    int trouve = 0;
    int j;
    int confirmation;

    printf("Entrez l'ID du client a supprimer : ");
    scanf("%d", &id_recherche);

    // Rechercher le client avec son ID
    for (j = 0; j < TAILLE_TAB_C; j++)
    {
        if (clients[j].idClient == id_recherche && clients[j].actif == 1)
        {
            trouve = 1;
            break;
        }
    }

    // Vérifier si le client existe
    if (trouve == 0)
    {
        printf("Aucun client associe a cet ID !\n");
        return;
    }

    // Afficher le client trouvé
    printf("Client trouve : %s %s\n",
           clients[j].nom, clients[j].prenom);

    // Demander confirmation
    printf("Confirmez-vous la suppression ?\n");
    printf("1. Oui\n");
    printf("2. Non\n");
    printf("Votre choix : ");
    scanf("%d", &confirmation);

    if (confirmation == 1)
    {
        clients[j].actif = 0;
        printf("\nLe client portant l'ID %d a ete supprime !\n", id_recherche);
    }
    else
    {
        printf("\nSuppression annulee.\n");
    }
}