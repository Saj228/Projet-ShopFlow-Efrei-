
#ifndef UTILS_H
#define UTILS_H

// Saisie sécurisée
int lireTexte(const char message[], char destination[], int taille);
int lireEntier(const char message[], int *valeur);
int lireReel(const char message[], float *valeur);

// Validation des données
int texteNonVide(const char texte[]);
int verifierEmail(const char email[]);
int verifierTelephone(const char telephone[]);
int verifierCodePostal(const char codePostal[]);

// Affichage formaté
void afficherTitre(const char titre[]);
void afficherSeparateur(int longueur);

#endif
