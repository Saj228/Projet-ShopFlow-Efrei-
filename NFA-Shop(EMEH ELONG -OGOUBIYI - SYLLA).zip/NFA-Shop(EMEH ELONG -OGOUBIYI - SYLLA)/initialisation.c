#include "initialisation.h"
#include "commande.h"
#include "produit.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Liberer les allocations de l'interieur vers l'exterieur : lignes,
 * commandes, clients et produits ; remettre ensuite la boutique a zero. */
void detruireBoutique(Boutique *b)
{
    if (b == NULL) return;
    for (int i = 0; i < b->nbClients; i++) {
        for (int j = 0; j < b->clients[i].nbCommandes; j++) {
            free(b->clients[i].commandes[j].lignes);
        }
        free(b->clients[i].commandes);
    }
    free(b->clients);
    free(b->produits);
    *b = (Boutique){0};
}

/* Construction du jeu de demonstration uniquement.
 * La creation interactive des commandes reste a terminer dans commande.c. */
static int ajouterCommandeDemo(Boutique *b, int indiceClient,
                              const char *statut, Date date,
                              const int *indices, const int *quantites, int n)
{
    Commande c = {0};
    Client *client = &b->clients[indiceClient];
    c.numero = b->numeroSuivant;
    c.idClient = client->idClient;
    c.dateCommande = date;
    /* Copier l'adresse : la commande garde celle choisie lors de sa creation. */
    c.adresseLivraison = client->adresse;
    snprintf(c.statut, sizeof c.statut, "%s", statut);
    int annulee = strcmp(statut, "ANNULEE") == 0;

    for (int i = 0; i < n; i++) {
        const Produit *p = &b->produits[indices[i]];
        if ((!annulee && quantites[i] > p->quantiteStock)
            || !ajouterLigne(&c, p->reference, p->designation,
                             quantites[i], p->prixUnitaireHT)) {
            free(c.lignes);
            return 0;
        }
    }
    int capacite = client->capaciteCommande;
    if (client->nbCommandes == capacite) {
        capacite = capacite == 0 ? 2 : capacite * 2;
        Commande *temp = realloc(client->commandes,
                                (size_t)capacite * sizeof(*temp));
        if (temp == NULL) {
            free(c.lignes);
            return 0;
        }
        client->commandes = temp;
        client->capaciteCommande = capacite;
    }
    client->commandes[client->nbCommandes++] = c;
    b->numeroSuivant++;
    if (!annulee) {
        for (int i = 0; i < n; i++) {
            b->produits[indices[i]].quantiteStock -= quantites[i];
        }
        client->pointsFidelite += (int)(c.montantTTC / 10.0f);
    }
    return 1;
}

int initialiserDonneesTest(Boutique *b)
{
    if (b == NULL || b->produits != NULL || b->clients != NULL
        || b->nbProduits != 0 || b->nbClients != 0) return 0;
    snprintf(b->NOM, sizeof b->NOM, "ShopFlow");
    b->numeroSuivant = 1001;
    b->idClientSuivant = 1;

    const Produit produits[] = {
        {"PRD-0001", "Clavier mecanique", "Informatique", 79.90f, 42, 10, 1},
        {"PRD-0002", "Souris sans fil", "Informatique", 24.50f, 8, 15, 1},
        {"PRD-0003", "Ecran 27 pouces", "Informatique", 199.00f, 6, 5, 1},
        {"PRD-0004", "Casque audio", "Audio", 89.90f, 25, 10, 1},
        {"PRD-0005", "Enceinte Bluetooth", "Audio", 59.90f, 12, 8, 1},
        {"PRD-0006", "Cable HDMI 2 m", "Accessoires", 9.90f, 120, 30, 1},
        {"PRD-0007", "Hub USB-C", "Accessoires", 49.90f, 4, 10, 1},
        {"PRD-0008", "Disque SSD 1 To", "Stockage", 109.00f, 18, 6, 1}
    };
    for (size_t i = 0; i < sizeof produits / sizeof produits[0]; i++) {
        if (!ajouterProduit(b, produits[i])) goto echec;
    }

    b->capaciteClients = 5;
    /* calloc initialise aussi a zero les compteurs et les pointeurs des clients. */
    b->clients = calloc((size_t)b->capaciteClients, sizeof(*b->clients));
    if (b->clients == NULL) goto echec;
    const char *noms[] = {"Bernard", "Martin", "Diallo", "Petit", "Moreau"};
    const char *prenoms[] = {"Julie", "Alex", "Sami", "Lina", "Camille"};
    const char *villes[] = {"Paris", "Lyon", "Lille", "Nantes", "Bordeaux"};
    const char *codes[] = {"75002", "69001", "59000", "44000", "33000"};
    for (int i = 0; i < 5; i++) {
        Client *client = &b->clients[i];
        client->idClient = b->idClientSuivant++;
        client->actif = 1;
        snprintf(client->nom, sizeof client->nom, "%s", noms[i]);
        snprintf(client->prenom, sizeof client->prenom, "%s", prenoms[i]);
        snprintf(client->email, sizeof client->email, "client%d@example.com", i + 1);
        snprintf(client->telephone, sizeof client->telephone, "060000000%d", i);
        snprintf(client->adresse.Rue, sizeof client->adresse.Rue, "%d rue des Tests", i + 1);
        snprintf(client->adresse.Ville, sizeof client->adresse.Ville, "%s", villes[i]);
        snprintf(client->adresse.codePostal, sizeof client->adresse.codePostal, "%s", codes[i]);
        snprintf(client->adresse.Pays, sizeof client->adresse.Pays, "France");
        b->nbClients++;
    }

    if (!ajouterCommandeDemo(b, 0, "LIVREE", (Date){1, 10, 2026},
                            (int[]){0, 1, 5}, (int[]){2, 1, 3}, 3)
        || !ajouterCommandeDemo(b, 1, "EXPEDIEE", (Date){10, 10, 2026},
                               (int[]){2, 3, 4}, (int[]){4, 1, 1}, 3)
        || !ajouterCommandeDemo(b, 2, "EN_COURS", (Date){15, 10, 2026},
                               (int[]){7}, (int[]){2}, 1)
        || !ajouterCommandeDemo(b, 0, "ANNULEE", (Date){20, 10, 2026},
                               (int[]){1}, (int[]){2}, 1)
        || !ajouterCommandeDemo(b, 3, "LIVREE", (Date){5, 9, 2026},
                               (int[]){6}, (int[]){1}, 1)
        || !ajouterCommandeDemo(b, 4, "EN_COURS", (Date){1, 11, 2026},
                               (int[]){5}, (int[]){2}, 1)) goto echec;
    return 1;

/* En cas d'echec, nettoyer les donnees deja allouees avant de retourner 0. */
echec:
    detruireBoutique(b);
    return 0;
}
